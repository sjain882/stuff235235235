-- This Source Code Form is subject to the terms of the bCDDL, v. 1.1.
-- If a copy of the bCDDL was not distributed with this
-- file, You can obtain one at http://beamng.com/bCDDL-1.1.txt

local M = {}

local devLayouts = {
  'gcDevMode',
  'gcDevModeA',
  'gcDevModeB',
  'gcDevModeC',
  'gcDevModeD',
  'gcDevModeE',
  'gcDevModeF',
  'gcDevModeG',
  'gcDevModeH',
  'gcDevModeI',
  'gcDevModeJ',
}

local devLayoutSet = {}
for _, name in ipairs(devLayouts) do
  devLayoutSet[name] = true
end

local function onExtensionLoaded()
  log('I', 'gcDevModeSwitch', 'Extension loaded successfully!')
end

local function onExtensionUnloaded()
  log('I', 'gcDevModeSwitch', 'Extension unloaded')
end

local function switchToLayout(targetLayout)
  local currentLayout = core_gamestate.state.appLayout

  if currentLayout == 'freeroam' then
    core_gamestate.setGameState('freeroam', targetLayout, 'freeroam')

  elseif currentLayout == targetLayout then
    core_gamestate.setGameState('freeroam', 'freeroam', 'freeroam')

  elseif devLayoutSet[currentLayout] then
    core_gamestate.setGameState('freeroam', targetLayout, 'freeroam')

  else
    guihooks.message("Cannot switch from " .. tostring(currentLayout), 3, "warning")
  end
end

local function onTestKeyPressed()   switchToLayout('gcDevMode')  end
local function onTestKeyAPressed()  switchToLayout('gcDevModeA') end
local function onTestKeyBPressed()  switchToLayout('gcDevModeB') end
local function onTestKeyCPressed()  switchToLayout('gcDevModeC') end
local function onTestKeyDPressed()  switchToLayout('gcDevModeD') end
local function onTestKeyEPressed()  switchToLayout('gcDevModeE') end
local function onTestKeyFPressed()  switchToLayout('gcDevModeF') end
local function onTestKeyGPressed()  switchToLayout('gcDevModeG') end
local function onTestKeyHPressed()  switchToLayout('gcDevModeH') end
local function onTestKeyIPressed()  switchToLayout('gcDevModeI') end
local function onTestKeyJPressed()  switchToLayout('gcDevModeJ') end

M.onExtensionLoaded     = onExtensionLoaded
M.onExtensionUnloaded   = onExtensionUnloaded
M.onTestKeyPressed      = onTestKeyPressed
M.onTestKeyAPressed     = onTestKeyAPressed
M.onTestKeyBPressed     = onTestKeyBPressed
M.onTestKeyCPressed     = onTestKeyCPressed
M.onTestKeyDPressed     = onTestKeyDPressed
M.onTestKeyEPressed     = onTestKeyEPressed
M.onTestKeyFPressed     = onTestKeyFPressed
M.onTestKeyGPressed     = onTestKeyGPressed
M.onTestKeyHPressed     = onTestKeyHPressed
M.onTestKeyIPressed     = onTestKeyIPressed
M.onTestKeyJPressed     = onTestKeyJPressed

return M